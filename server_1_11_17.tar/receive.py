
def recv(:):
	str  = "281004"
